<!-- resources/views/products/index.blade.php -->

@extends('layouts.app')

@section('conteudo')
    <h2>Listagem de Produtos</h2>
    
    @if(session('sucesso'))
        <div class="alert alert-success">
            {{ session('sucesso') }}
        </div>
    @endif

    <table class="table">
        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Nome</th>
                <th scope="col">Descrição</th>
                <th scope="col">Quantidade</th>
                <th scope="col">Valor</th>
                <th scope="col">Categoria</th>
                <th scope="col">Origem</th>
                <th scope="col">Ações</th>
            </tr>
        </thead>
        <tbody>
            @foreach($produtos as $produto)
                <tr>
                    <td>{{ $produto->id }}</td>
                    <td>{{ $produto->nome }}</td>
                    <td>{{ $produto->descricao }}</td>
                    <td>{{ $produto->quantidade }}</td>
                    <td>{{ $produto->valor }}</td>
                    <td>{{ $produto->categoria }}</td>
                    <td>{{ $produto->origem }}</td>
                    <td>
                        <a href="{{ route('produto.editar', $produto->id) }}" class="btn btn-primary">Editar</a>
                        <form action="{{ route('produto.deletar', $produto->id) }}" method="POST" style="display: inline;">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger" onclick="return confirm('Deseja realmente excluir?')">Excluir</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
@endsection
