<?php $__env->startSection('login'); ?>
    <div class="container"> 
        <form action="<?php echo e(route('login')); ?>" method="get">
            <?php echo csrf_field(); ?> 
            <div class="form-group">
                <label for="usuario">Nome do Usuário</label>
                <input type="text" class="form-control" id="usuario" placeholder="Digite seu usuário" name="login">
            </div>

            <div class="form-group">
                <label for="senha">Senha</label>
                <input type="password" name="senha" id="senha" placeholder="Digite sua senha">
            </div>

            <button type="submit" class="btn btn-primary">Entrar</button>
        </form>

       
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(Auth::check()): ?>
        <div class="mt-3">
            <p>Escolha para onde ir após o login:</p>
            <ul>
                <li><a href="<?php echo e(route('usuarios.index')); ?>">Ir para Usuários</a></li>
                <li><a href="<?php echo e(route('produtos.index')); ?>">Ir para Produtos</a></li>
            </ul>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projetoAula\resources\views/login.blade.php ENDPATH**/ ?>