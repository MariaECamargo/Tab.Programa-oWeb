<!-- resources/views/products/index.blade.php -->



<?php $__env->startSection('conteudo'); ?>
    <h2>Listagem de Produtos</h2>
    
    <?php if(session('sucesso')): ?>
        <div class="alert alert-success">
            <?php echo e(session('sucesso')); ?>

        </div>
    <?php endif; ?>

    <table class="table">
        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Nome</th>
                <th scope="col">Descrição</th>
                <th scope="col">Quantidade</th>
                <th scope="col">Valor</th>
                <th scope="col">Categoria</th>
                <th scope="col">Origem</th>
                <th scope="col">Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($produto->id); ?></td>
                    <td><?php echo e($produto->nome); ?></td>
                    <td><?php echo e($produto->descricao); ?></td>
                    <td><?php echo e($produto->quantidade); ?></td>
                    <td><?php echo e($produto->valor); ?></td>
                    <td><?php echo e($produto->categoria); ?></td>
                    <td><?php echo e($produto->origem); ?></td>
                    <td>
                        <a href="<?php echo e(route('produto.editar', $produto->id)); ?>" class="btn btn-primary">Editar</a>
                        <form action="<?php echo e(route('produto.deletar', $produto->id)); ?>" method="POST" style="display: inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger" onclick="return confirm('Deseja realmente excluir?')">Excluir</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projetoAula\resources\views/produtos/index.blade.php ENDPATH**/ ?>